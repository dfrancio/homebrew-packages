
#ifndef CPPORM_EXPORT_H
#define CPPORM_EXPORT_H

#ifdef CPPORM_STATIC_DEFINE
#  define CPPORM_EXPORT
#  define CPPORM_NO_EXPORT
#else
#  ifndef CPPORM_EXPORT
#    ifdef cpporm_EXPORTS
        /* We are building this library */
#      define CPPORM_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define CPPORM_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef CPPORM_NO_EXPORT
#    define CPPORM_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef CPPORM_DEPRECATED
#  define CPPORM_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef CPPORM_DEPRECATED_EXPORT
#  define CPPORM_DEPRECATED_EXPORT CPPORM_EXPORT CPPORM_DEPRECATED
#endif

#ifndef CPPORM_DEPRECATED_NO_EXPORT
#  define CPPORM_DEPRECATED_NO_EXPORT CPPORM_NO_EXPORT CPPORM_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef CPPORM_NO_DEPRECATED
#    define CPPORM_NO_DEPRECATED
#  endif
#endif

#endif
