#pragma once

#define CPPORM_VERSION "0.2.20"
#define CPPORM_VERSION_MAJOR 0
#define CPPORM_VERSION_MINOR 2
#define CPPORM_USE_DUAL_ABI 1

#if !CPPORM_USE_DUAL_ABI
// Ignore any pre-defined value of CPPORM_USE_CXX11_ABI
#undef CPPORM_USE_CXX11_ABI
#endif

#ifndef CPPORM_USE_CXX11_ABI
#define CPPORM_USE_CXX11_ABI 1
#endif

#if CPPORM_USE_CXX11_ABI
// Macros for ABI tag attributes.
#ifndef CPPORM_ABI_TAG_CXX11
#if __GNUC__ && !(__llvm__ || __clang__)
#define CPPORM_ABI_TAG_CXX11 __attribute((__abi_tag__("cxx11")))
#else
#define CPPORM_ABI_TAG_CXX11
#endif
#endif
#define CPPORM_NAMESPACE_CXX11 __cxx11::
#define CPPORM_BEGIN_NAMESPACE_CXX11 \
    inline namespace __cxx11 \
    {
#define CPPORM_END_NAMESPACE_CXX11 }
#define CPPORM_DEFAULT_ABI_TAG CPPORM_ABI_TAG_CXX11
#else
#define CPPORM_NAMESPACE_CXX11
#define CPPORM_BEGIN_NAMESPACE_CXX11
#define CPPORM_END_NAMESPACE_CXX11
#define CPPORM_DEFAULT_ABI_TAG
#endif

#define CPPORM_BEGIN_NAMESPACE \
    namespace cpporm \
    { \
    CPPORM_BEGIN_NAMESPACE_CXX11
#define CPPORM_END_NAMESPACE \
    CPPORM_END_NAMESPACE_CXX11 \
    }

#define CPPORM_BEGIN_SUB_NAMESPACE(name) \
    CPPORM_BEGIN_NAMESPACE \
    namespace name \
    {
#define CPPORM_END_SUB_NAMESPACE \
    } \
    CPPORM_END_NAMESPACE

#define CPPORM_BEGIN_SUB_SUB_NAMESPACE(name1, name2) \
    CPPORM_BEGIN_SUB_NAMESPACE(name1) \
    namespace name2 \
    {
#define CPPORM_END_SUB_SUB_NAMESPACE \
    } \
    CPPORM_END_SUB_NAMESPACE

/*! \brief Namespace cpporm */
namespace cpporm
{
#if CPPORM_USE_CXX11_ABI
/*! \brief Namespace __cxx11 */
inline namespace __cxx11 CPPORM_ABI_TAG_CXX11
{
}
#endif
}
