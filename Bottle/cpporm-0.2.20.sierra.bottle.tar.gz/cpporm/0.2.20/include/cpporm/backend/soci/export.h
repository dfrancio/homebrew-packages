
#ifndef CPPORM_SOCI_EXPORT_H
#define CPPORM_SOCI_EXPORT_H

#ifdef CPPORM_SOCI_STATIC_DEFINE
#  define CPPORM_SOCI_EXPORT
#  define CPPORM_SOCI_NO_EXPORT
#else
#  ifndef CPPORM_SOCI_EXPORT
#    ifdef cpporm_soci_EXPORTS
        /* We are building this library */
#      define CPPORM_SOCI_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define CPPORM_SOCI_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef CPPORM_SOCI_NO_EXPORT
#    define CPPORM_SOCI_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef CPPORM_SOCI_DEPRECATED
#  define CPPORM_SOCI_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef CPPORM_SOCI_DEPRECATED_EXPORT
#  define CPPORM_SOCI_DEPRECATED_EXPORT CPPORM_SOCI_EXPORT CPPORM_SOCI_DEPRECATED
#endif

#ifndef CPPORM_SOCI_DEPRECATED_NO_EXPORT
#  define CPPORM_SOCI_DEPRECATED_NO_EXPORT CPPORM_SOCI_NO_EXPORT CPPORM_SOCI_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef CPPORM_SOCI_NO_DEPRECATED
#    define CPPORM_SOCI_NO_DEPRECATED
#  endif
#endif

#endif
